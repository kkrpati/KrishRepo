I have included the final script build in the module (test.jmx).

To open it in JMeter, go to File -> Open.

JMeter's component reference
https://jmeter.apache.org/usermanual/component_reference.html