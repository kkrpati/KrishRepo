I have included the final script recorded in the module (recorded-test-final.jmx), and the one in the clip 04 (recorded-test-original.jmx).

To open it in JMeter, go to File -> Open.

BlazeMeter Chrome Extension
https://chrome.google.com/webstore/detail/blazemeter-the-continuous/mbopgmdnpcbohhpnfglgohlbhfongabi?hl=en

Documentation
https://guide.blazemeter.com/hc/en-us/articles/206732579-Chrome-Extension